#pragma once

#include "ix_scan.h"
#include "ix_manager.h"
